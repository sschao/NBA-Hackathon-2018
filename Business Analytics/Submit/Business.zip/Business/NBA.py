#Defined below is the Neural Network to predict International Viewership of NBA Games
#The Training Input that is necessary is a 2000x4 csv file containing data about Win Differential, Combined Loss, Per Team Social Media Following, and Per Team Market Revenue for 2000 games
#The Training Output that is necessary is a 2000x1 csv file detailing total International Viewership
#This Network can be applied to data on upcoming games to predict International Viewership

import numpy
import numpy as np

filename = 'Input.csv'
raw_data = open(filename, 'rt')
data = numpy.loadtxt(raw_data, delimiter=",")

filename = 'Output.csv'
raw_data1 = open(filename, 'rt')
array_data1 = numpy.loadtxt(raw_data1, delimiter=",")
data11 = numpy.array([array_data1])
data1 = data11.T

filename = 'Input Test.csv'
raw_data2 = open(filename, 'rt')
data2 = numpy.loadtxt(raw_data2, delimiter=",")

X = data # Training Input
y = data1 # Training Target

Z = data2 # Test Data (Referred to separately)

class Neural_Net(object):
  def __init__(self):
    #Parameters
    self.input = 4
    self.output = 1
    self.hidden = 2000

    #Weights
    self.L1_Weight = np.random.randn(self.input, self.hidden) 
    self.L2_Weight = np.random.randn(self.hidden, self.output) 

  def forward(self, X):
    #Forward Prop
    self.A = np.dot(X, self.L1_Weight)
    self.A2 = self.sigmoid(self.A) # Primary Activation Function
    self.A3 = np.dot(self.A2, self.L2_Weight) 
    B = self.sigmoid(self.A3) # Secondary Activation Function
    return B

  def __init__(self, layer1, layer2):
        self.layer1 = layer1
        self.layer2 = layer2
        
  def sigmoid(self, s):
    # Activation Function
    return 1 / (1 + np.exp(-s))


  def sigmoidPrime(self, s):
    # Sigmoid Derivative
    return s * (1 - s)


  def backward(self, X, y, B):
    # Back Prop
    self.B_error = y - B # Ouptut Error
    self.B_delta = self.B_error * self.sigmoidPrime(B)  # Sigmoid derivative on Error

    self.A2_error = self.B_delta.dot(
        self.L2_Weight.T)  # Calculating Weight impact on error for backprop
    self.A2_delta = self.A2_error * self.sigmoidPrime(self.A2)  # Sigmoid derivative on Error

    self.L1_Weight += X.T.dot(self.A2_delta)  # Primary Weight Adjustment
    self.L2_Weight += self.A2.T.dot(self.B_delta)  # Secondary Weight Adjustment


  def train(self, X, y):
    # Training
    B = self.forward(X)
    self.backward(X, y, B)

  #def saveWeights(self):
    # Backup - Non necessary
    #np.savetxt("L1_Weight.txt", self.L1_Weight, fmt="%s")
    #np.savetxt("L2_Weight.txt", self.L2_Weight, fmt="%s")

  def predict(self):
    print("Predicted Views based on trained weights: ");
    print("Input (scaled): \n" + str(Z));
    print("Output: \n" + str(self.forward(Z)));


NN = Neural_Network()
for i in range(60000):  # 50,000 epochs
    #print(" #" + str(i) + "\n")
    #print("Input (scaled): \n" + str(X))
    #print("Actual Output: \n" + str(y))
    #print("Predicted Output: \n" + str(NN.forward(X)))
    #print("\n")
    print("Loss: \n" + str(np.mean(np.square(y - NN.forward(X)))))  # Loss
    NN.train(X, y) #Uncomment lines above for detailed analysis of Input, AO, PO, and number tracking. Loss is a must.
    
NN.predict() #Calls previously defined predict to test trained net on new data