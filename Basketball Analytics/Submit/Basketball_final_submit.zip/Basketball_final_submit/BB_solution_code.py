
import csv 

def teampair(game):
	"""
	'game' is a string denoting the game we're in 
	"""
	teams = []
	with open("Game_Lineup_Data_Sample.csv","r") as csvfile:
		readCSV = csv.reader(csvfile, delimiter = ',')

		for row in readCSV:
			if row[0] == "Game_id":
				pass
			elif row[0] == game:
				if row[3] not in teams:
					teams.append(row[3])
	return(teams[0],teams[1])

def start_lineup(game, period, dictPlayers, T0, T1):
	with open("Game_Lineup_Data_Sample.csv","r") as csvfile:
		readCSV = csv.reader(csvfile, delimiter = ',')

		reachedGame = False 
		T0_on = []
		T1_on = []

		for row in readCSV:
			if row[0] == game:
				reachedGame = True
				if int(row[1]) == period:
					if row[3] == T0:
						T0_on.append(row[2])
						if row[2] not in dictPlayers:
							dictPlayers[row[2]] = 0 
					elif row[3] == T1:
						T1_on.append(row[2])
						if row[2] not in dictPlayers:
							dictPlayers[row[2]] = 0 
			elif reachedGame:
				break
	return(dictPlayers, T0_on, T1_on)


def update_box(T0_score_prev, T0_score_diff, dictPlayers, T0_on, T1_on):
	T0_delta = T0_score_diff - T0_score_prev 
	for player in T0_on:
		dictPlayers[player] = dictPlayers.get(player,0) + T0_delta  
	for player in T1_on:
		dictPlayers[player] = dictPlayers.get(player,0) - T0_delta
	return(dictPlayers)

def substitution(team_id, T0_on, T1_on, T0, T1, p1, p2):
	if team_id == T0:
		try:
			T0_on.remove(p1)
			T0_on.append(p2)
		except ValueError:
			T1_on.remove(p1)
			T1_on.append(p2)
			#print(row)
	elif team_id == T1:
		try:
			T1_on.remove(p1)
			T1_on.append(p2)
		except ValueError:
			T0_on.remove(p1)
			T0_on.append(p2)
	return(T0_on, T1_on)
	

#Start of our program 
filename = "Chicoreian_Q1_BBALL.csv"
f = open(filename, "w")
#opens file and writes it meaning the existing file with the same name will be erased
headers = "Game_ID,Player_ID,Player_Plus/Minus\n"
f.write(headers)

games = []

with open("list_of_games.csv","r") as csvfile: #create a list of games 
	readCSV = csv.reader(csvfile, delimiter = ',')

	for row in readCSV:
		if row[0] == "Game_id":
			continue
		games.append(row[0])

with open("Play_by_Play_Data_Sample.csv", "r") as csvfile: #create a list of games with 5 periods
	readCSV = csv.reader(csvfile, delimiter = ',')

	game5s = []

	for row in readCSV:
		if row[0] == "Game_id":
			pass
		elif int(row[3]) == 5:
			if row[0] not in game5s:
				game5s.append(row[0])


with open("Play_by_Play_Data_Sample.csv","r") as csvfile:
	readCSV = csv.reader(csvfile, delimiter = ',')

	for game in games:
		dictPlayers = {}

		T0_score_prev = 0 
		T0_score_diff = 0 

		T0_on = []
		T1_on = []
		T0, T1 = teampair(game)



		isFoul = False #This means we're still facing the consequences of a foul 
		queue = []
		for row in readCSV:
			if row[0] == "Game_id":
				continue
			elif row[0] == game:

				if int(row[2]) in [1,2,5,10,11,12,13]:
					isFoul = False
					for triple in queue:
						dictPlayers = update_box(T0_score_prev, T0_score_diff, dictPlayers, T0_on, T1_on)#update dictionary of players 
						T0_score_prev = T0_score_diff #update the differential
						T0_on, T1_on = substitution(triple[0], T0_on, T1_on, T0, T1, triple[1], triple[2]) #Update who's on the court
					queue = []

				if int(row[2]) == 1: #If event_msg is a made shot
					if row[10] ==T0: #check which team the score belongs to 
						T0_score_diff += int(row[7])
					elif row[10] == T1:
						T0_score_diff -= int(row[7])


				elif int(row[2]) == 6: #Foul is triggered 
					isFoul = True 
					continue 

				elif int(row[2]) == 3: #if event_msg is a free throw 
					if int(row[7]) == 1: #if the shot is made 
						if row[10] ==T0: #check which team it belongs to 
							T0_score_diff += int(row[7])
						if row[10] == T1:
							T0_score_diff -= int(row[7])

				elif int(row[2]) == 8: #if a substitution is called 
					if not isFoul: 
						dictPlayers = update_box(T0_score_prev, T0_score_diff, dictPlayers, T0_on, T1_on)#update dictionary of players 
						T0_score_prev = T0_score_diff #update the differential 
						T0_on, T1_on = substitution(row[10], T0_on, T1_on, T0, T1, row[11], row[12]) #Update who's on the court 
					elif isFoul:
						queue.append([row[10],row[11],row[12]])

				elif int(row[2]) == 12: #Start of a new period 
					dictPlayers, T0_on, T1_on = start_lineup(game, int(row[3]), dictPlayers, T0, T1)

				elif int(row[2]) == 13: #End of a period 
					dictPlayers = update_box(T0_score_prev, T0_score_diff, dictPlayers, T0_on, T1_on) #update dictionary of players
					if game not in game5s:
						if int(row[3]) == 4: #End of a game 
							for person in dictPlayers:
								f.write(game + "," + person + "," + str(dictPlayers[person]) +  "\n")
							break
					if game in game5s:
						if int(row[3]) == 5: #End of a game with 5 periods 
							for person in dictPlayers:
								f.write(game + "," + person + "," + str(dictPlayers[person]) +  "\n")							
							break 



f.close()
